package pe.edu.upeu.asistencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysAsistenciaAnApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysAsistenciaAnApplication.class, args);
	}

}
