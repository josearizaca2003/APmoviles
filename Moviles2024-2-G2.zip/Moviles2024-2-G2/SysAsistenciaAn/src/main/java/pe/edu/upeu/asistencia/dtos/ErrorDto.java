package pe.edu.upeu.asistencia.dtos;

public record ErrorDto (String message) { }
