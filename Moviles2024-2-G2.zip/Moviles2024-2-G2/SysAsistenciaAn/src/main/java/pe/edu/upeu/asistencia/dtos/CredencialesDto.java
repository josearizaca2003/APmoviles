package pe.edu.upeu.asistencia.dtos;

public record CredencialesDto (String correo, char[] password) { }