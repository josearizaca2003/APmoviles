package pe.edu.upeu.navegacionjpc.utils

import android.content.Context

object conttexto{
    lateinit var CONTEXTO_APPX: Context
}