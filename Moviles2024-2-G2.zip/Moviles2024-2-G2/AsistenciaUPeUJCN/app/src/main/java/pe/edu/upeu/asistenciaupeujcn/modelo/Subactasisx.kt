package pe.edu.upeu.asistenciaupeujcn.modelo

data class Subactasisx(
    var id: Long,
    var fecha: String,
    var horasi: String,
    var minToler: String,
    var estado: String,
    var offlinex: String,
    var actividadId: String,
)