package pe.edu.upeu.asistenciaupeujcn.modelo

data class MsgGeneric(var deleted:Boolean)
