package pe.edu.upeu.asistenciaupeujcn.utils

import android.content.Context

object TokenUtils {
    var TOKEN_CONTENT="Aqui va el Token"
    var API_URL="http://172.22.1.50:8090/"
    lateinit var CONTEXTO_APPX: Context
    var USER_LOGIN=""
    var ID_ASIS_ACT=0L
}