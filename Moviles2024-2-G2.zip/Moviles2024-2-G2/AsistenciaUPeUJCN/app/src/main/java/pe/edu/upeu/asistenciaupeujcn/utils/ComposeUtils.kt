package pe.edu.upeu.asistenciaupeujcn.utils

import androidx.compose.runtime.Composable

object ComposeReal{
    var COMPOSE_TOP: @Composable ()-> Unit={}
    var TITLE_TOP:String=""
}